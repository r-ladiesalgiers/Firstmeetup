# manipuler_donn-es_SQL_R_tidyverse
Cette présentation et le script y afférent ont été présenté par l'occasion du premier meet-up de R Ladies Algiers tenu le 04 Janvier 2020. 
